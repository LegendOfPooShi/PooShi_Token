﻿#include "pch-c.h"
#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif


#include "codegen/il2cpp-codegen-metadata.h"





// 0x00000001 System.Void UnityEngine.U2D.Common.InternalEngineBridge::SetLocalAABB(UnityEngine.SpriteRenderer,UnityEngine.Bounds)
extern void InternalEngineBridge_SetLocalAABB_m3D06BEA2796AA10E1D89984123EA3957B71CB710 (void);
// 0x00000002 System.Void UnityEngine.U2D.Common.InternalEngineBridge::SetDeformableBuffer(UnityEngine.SpriteRenderer,Unity.Collections.NativeArray`1<System.Byte>)
extern void InternalEngineBridge_SetDeformableBuffer_m1D6A4A8AA50AAD97008D5DEBE84DFE7F5FF0D4AA (void);
static Il2CppMethodPointer s_methodPointers[2] = 
{
	InternalEngineBridge_SetLocalAABB_m3D06BEA2796AA10E1D89984123EA3957B71CB710,
	InternalEngineBridge_SetDeformableBuffer_m1D6A4A8AA50AAD97008D5DEBE84DFE7F5FF0D4AA,
};
static const int32_t s_InvokerIndices[2] = 
{
	2788,
	2786,
};
extern const CustomAttributesCacheGenerator g_Unity_InternalAPIEngineBridge_001_AttributeGenerators[];
IL2CPP_EXTERN_C const Il2CppCodeGenModule g_Unity_InternalAPIEngineBridge_001_CodeGenModule;
const Il2CppCodeGenModule g_Unity_InternalAPIEngineBridge_001_CodeGenModule = 
{
	"Unity.InternalAPIEngineBridge.001.dll",
	2,
	s_methodPointers,
	0,
	NULL,
	s_InvokerIndices,
	0,
	NULL,
	0,
	NULL,
	0,
	NULL,
	NULL,
	g_Unity_InternalAPIEngineBridge_001_AttributeGenerators,
	NULL, // module initializer,
	NULL,
	NULL,
	NULL,
};
