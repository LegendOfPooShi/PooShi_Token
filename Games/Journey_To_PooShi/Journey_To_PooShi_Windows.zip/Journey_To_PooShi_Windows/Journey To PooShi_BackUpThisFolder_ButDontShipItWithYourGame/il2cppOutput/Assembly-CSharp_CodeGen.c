﻿#include "pch-c.h"
#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif


#include "codegen/il2cpp-codegen-metadata.h"





// 0x00000001 System.Void Bomb::Awake()
extern void Bomb_Awake_m3CAE1647F328E5892A740D9B204F45CD6151FE7B (void);
// 0x00000002 System.Void Bomb::OnEnable()
extern void Bomb_OnEnable_m958CE4A6DEFF85ACDBFBEBDA11597CA4390ED6DE (void);
// 0x00000003 System.Void Bomb::LateUpdate()
extern void Bomb_LateUpdate_mE0774F654B770E2DBCCA0AEC6D3A82B42D65D46E (void);
// 0x00000004 System.Void Bomb::OnTriggerEnter2D(UnityEngine.Collider2D)
extern void Bomb_OnTriggerEnter2D_mA28DDFBF317D52558D3C862B97FE2CCACD536C4B (void);
// 0x00000005 System.Void Bomb::.ctor()
extern void Bomb__ctor_mB4A4B674437E391EA003374752A044DD5E539C46 (void);
// 0x00000006 System.Boolean Car::get_CanUserControlCar()
extern void Car_get_CanUserControlCar_m8572284F5EFCD88356175AB5E4B28FB8F606E38F (void);
// 0x00000007 System.Void Car::set_CanUserControlCar(System.Boolean)
extern void Car_set_CanUserControlCar_mDB05A2D97C0C5BB52F25A3579BBB2188CED96644 (void);
// 0x00000008 System.Single Car::get_CurrentPlayerScore()
extern void Car_get_CurrentPlayerScore_m9837D40FBC143AD134B90BA2BA8F3018EB836C32 (void);
// 0x00000009 System.Void Car::set_CurrentPlayerScore(System.Single)
extern void Car_set_CurrentPlayerScore_mBF251B44F6A5E2A60DE1ED861EEA36D0E1260E02 (void);
// 0x0000000A System.Single Car::get_SecondsSinceCarJumped()
extern void Car_get_SecondsSinceCarJumped_m7F28F63B0AA41937809824875028BF67486AF8BC (void);
// 0x0000000B System.Void Car::set_SecondsSinceCarJumped(System.Single)
extern void Car_set_SecondsSinceCarJumped_m4222904582351A40837ED7868D3BC5D826A7E3C9 (void);
// 0x0000000C System.Single Car::get_SecondsTraveled()
extern void Car_get_SecondsTraveled_m158517E5F70D02FE193C8E0ED2953A10A8EAEDB8 (void);
// 0x0000000D System.Void Car::set_SecondsTraveled(System.Single)
extern void Car_set_SecondsTraveled_m3A39BDAD1EE34BA288BE48979B8E594C8F82DBA0 (void);
// 0x0000000E System.Void Car::SetCarLocation(UnityEngine.Vector3)
extern void Car_SetCarLocation_m2293F8839C9B2E809672120115AAC25B73EED207 (void);
// 0x0000000F System.Void Car::SetCarLane(System.Single)
extern void Car_SetCarLane_m2DAE9CE0E23AF7EDEA8E8AA542456E0B9D408A4A (void);
// 0x00000010 System.Void Car::HitPooShiTokenObject()
extern void Car_HitPooShiTokenObject_mB575C683F118DC320BFF09348CB885CBE55FA265 (void);
// 0x00000011 System.Void Car::HitEnemyObject()
extern void Car_HitEnemyObject_m12E4CAD61E63F2834BFF879B2C21560B29E19CF7 (void);
// 0x00000012 System.Void Car::PauseTires()
extern void Car_PauseTires_m3EBB0006938DF58E224014B99942A2EFC2BD907A (void);
// 0x00000013 System.Void Car::Awake()
extern void Car_Awake_mC9635C2EA709050BC6D4D33E1BF86832E87EC810 (void);
// 0x00000014 System.Void Car::OnEnable()
extern void Car_OnEnable_m56F5514A8EC5B8C8AC345DA8D41F179D57309096 (void);
// 0x00000015 System.Void Car::Update()
extern void Car_Update_mB15FECA4B76ADEA6E4C71AF5DDC72D8EC17E1D62 (void);
// 0x00000016 System.Void Car::OnDisable()
extern void Car_OnDisable_mAECFB1D7A7DD266119B0A562CB2C81892BDC76C9 (void);
// 0x00000017 System.Void Car::CheckForCarLocationShift()
extern void Car_CheckForCarLocationShift_m9352E1D652B746D4687CCE43104BFCB0A54FCB00 (void);
// 0x00000018 System.Void Car::checkSwipe()
extern void Car_checkSwipe_m9B007E8108EE06817B236F252590AEF7EEFDD2C4 (void);
// 0x00000019 System.Void Car::OnSwipeUp()
extern void Car_OnSwipeUp_mF32BA98869EA657A5E036C63F953C9BAFC62115D (void);
// 0x0000001A System.Void Car::OnSwipeDown()
extern void Car_OnSwipeDown_mC4524A8D87D7641F3DF9C0A9BE43D91D556BB146 (void);
// 0x0000001B System.Void Car::OnSwipeLeft()
extern void Car_OnSwipeLeft_mF67789B868BAF946577D852E3C3EF07911AFBD68 (void);
// 0x0000001C System.Void Car::OnSwipeRight()
extern void Car_OnSwipeRight_mAD96A20DD9C635BE120B6EB7165B8C7E126D319A (void);
// 0x0000001D System.Single Car::verticalMove()
extern void Car_verticalMove_m0B00BB61FC62C5BD7B1C429EF1AFD2D12979698B (void);
// 0x0000001E System.Single Car::horizontalValMove()
extern void Car_horizontalValMove_m59335620200DF2A2E67C15F0313EBA0AF856AF6F (void);
// 0x0000001F System.Void Car::CheckForCarJumping()
extern void Car_CheckForCarJumping_m44C5A9B8D13D706159190D0DB75F1B37AB31F3C2 (void);
// 0x00000020 System.Void Car::MakeCarJump()
extern void Car_MakeCarJump_m76A85DA81CA8DB5E618E91D6F04DA41D89772444 (void);
// 0x00000021 System.Void Car::.ctor()
extern void Car__ctor_m60DBEB43627049079D3DB87585F1E132B1C4DC41 (void);
// 0x00000022 System.Void Boss::Awake()
extern void Boss_Awake_m32F745C33261137293AF3BBD526A529174C5AB58 (void);
// 0x00000023 System.Void Boss::OnEnable()
extern void Boss_OnEnable_m55182DBB17650F52FBF4AE94E78E1FAA201D8F29 (void);
// 0x00000024 System.Void Boss::Update()
extern void Boss_Update_m7B73B59D0659578B1A73EB64D4586ADF8F594076 (void);
// 0x00000025 System.Void Boss::UpdateWinCondition()
extern void Boss_UpdateWinCondition_m21EF451957D90A1086FD4F0E9FA5BAF6CC03108C (void);
// 0x00000026 System.Void Boss::OnDisable()
extern void Boss_OnDisable_m76EFE4AAC7E4DFA33360B2C6D21875C07F41F7E4 (void);
// 0x00000027 System.Void Boss::UpdateMovement()
extern void Boss_UpdateMovement_mDAD53B14F3AF7C65B362B05A3B4C1420FAE0529B (void);
// 0x00000028 System.Void Boss::UpdateBossPositioning()
extern void Boss_UpdateBossPositioning_mDD28F9F428DC253BD9809AB59920548F4DCD6D75 (void);
// 0x00000029 System.Void Boss::OnTriggerEnter2D(UnityEngine.Collider2D)
extern void Boss_OnTriggerEnter2D_mD32AC8A2D12580C3817A0F21E2A3A8F9B70D4D9A (void);
// 0x0000002A System.Collections.IEnumerator Boss::EagleDefeated()
extern void Boss_EagleDefeated_mBCD93039FC51A309FC65CD1304BE1B28906F02A6 (void);
// 0x0000002B System.Void Boss::EnsureBossFacesCar()
extern void Boss_EnsureBossFacesCar_m2F76F04AA408DFD059A5A6DC30D63033BEC4842F (void);
// 0x0000002C System.Void Boss::.ctor()
extern void Boss__ctor_mCEB1D7BFC2C85DF7CE281A5BB76D0D55ADFB089F (void);
// 0x0000002D System.Void Boss/<EagleDefeated>d__40::.ctor(System.Int32)
extern void U3CEagleDefeatedU3Ed__40__ctor_mC9FAA57839803C59541F79B634A4C2D14C21E668 (void);
// 0x0000002E System.Void Boss/<EagleDefeated>d__40::System.IDisposable.Dispose()
extern void U3CEagleDefeatedU3Ed__40_System_IDisposable_Dispose_m93894B4013E24145808485BD9BE48ECBC6351454 (void);
// 0x0000002F System.Boolean Boss/<EagleDefeated>d__40::MoveNext()
extern void U3CEagleDefeatedU3Ed__40_MoveNext_m6B3CF1042B162B6CA98459163E21BDD267E013E3 (void);
// 0x00000030 System.Object Boss/<EagleDefeated>d__40::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CEagleDefeatedU3Ed__40_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m12397C7DFA237A3F2B3F437A2476D62B5E50E500 (void);
// 0x00000031 System.Void Boss/<EagleDefeated>d__40::System.Collections.IEnumerator.Reset()
extern void U3CEagleDefeatedU3Ed__40_System_Collections_IEnumerator_Reset_m5FE885E4B9EC1EC55287B05E3F8FAFF5AD0761C6 (void);
// 0x00000032 System.Object Boss/<EagleDefeated>d__40::System.Collections.IEnumerator.get_Current()
extern void U3CEagleDefeatedU3Ed__40_System_Collections_IEnumerator_get_Current_m182C7C1F23627D8E12D971B13A12450726A8DEC1 (void);
// 0x00000033 System.Void PooShi::Awake()
extern void PooShi_Awake_mFE54EC4322737B548473ACB9074B0B5AEB820EC3 (void);
// 0x00000034 System.Void PooShi::OnTriggerEnter2D(UnityEngine.Collider2D)
extern void PooShi_OnTriggerEnter2D_mF33DF71F37CF957528CC48F69D5B50B9A9B215D6 (void);
// 0x00000035 System.Void PooShi::.ctor()
extern void PooShi__ctor_mEFECE90667F14E7B25A792FAD2C75DE34F569395 (void);
// 0x00000036 System.Void PooShiToken::LateUpdate()
extern void PooShiToken_LateUpdate_mCB9763D3D4E607D9F3966ED9C29F728FFA746CB7 (void);
// 0x00000037 System.Void PooShiToken::Awake()
extern void PooShiToken_Awake_mCEB19DA91375FA624556B71318B44093A8516AE9 (void);
// 0x00000038 System.Void PooShiToken::OnTriggerEnter2D(UnityEngine.Collider2D)
extern void PooShiToken_OnTriggerEnter2D_mFDBA78D9845C1BED18D7645E39EC216FDA863DE0 (void);
// 0x00000039 System.Void PooShiToken::.ctor()
extern void PooShiToken__ctor_mCED088E476E47F0A397EE63BCC3D32EEFE67CF6F (void);
// 0x0000003A System.Void EnemyManager::ActivateTheBoss()
extern void EnemyManager_ActivateTheBoss_m3F8FC1675888FDF693A536945DBE768068773E30 (void);
// 0x0000003B System.Void EnemyManager::DeactivateTheBoss()
extern void EnemyManager_DeactivateTheBoss_m2A7127F09B0CBA522D92BAFB5531C5315DA46419 (void);
// 0x0000003C System.Void EnemyManager::ActivateBombTokenSpawner()
extern void EnemyManager_ActivateBombTokenSpawner_m14FB41BCD0BD053517BBFA431A403C09A86BCF48 (void);
// 0x0000003D System.Void EnemyManager::DeactivateBombTokenSpawner()
extern void EnemyManager_DeactivateBombTokenSpawner_m0F5EE07A94C3F7CE4F4DBE4A1A2A592EAB5A9E35 (void);
// 0x0000003E System.Void EnemyManager::ActivateNextEnemy(EnemyManager/EnemyType,UnityEngine.Vector3)
extern void EnemyManager_ActivateNextEnemy_m195BE71D15445330107EEC61639570B0EDCC697A (void);
// 0x0000003F System.Void EnemyManager::Awake()
extern void EnemyManager_Awake_mCF0CE37D0C822B260FC50D3E278273C48E1EAFFD (void);
// 0x00000040 System.Void EnemyManager::Update()
extern void EnemyManager_Update_mDAF54A6B65BC212734D1F2A4A6113774B609D144 (void);
// 0x00000041 System.Void EnemyManager::OnDisable()
extern void EnemyManager_OnDisable_m137513726C7A2C599CFFF2E62DE5EDA04A0A0A53 (void);
// 0x00000042 System.Void EnemyManager::.ctor()
extern void EnemyManager__ctor_mBDFE0474595BA9BB75EA8A31AD431DD91E7EB250 (void);
// 0x00000043 System.Void HorizontalScrollerUI::UserWon()
extern void HorizontalScrollerUI_UserWon_mC6D3206A2C964D0B09F5AD083F3F013DD2DECE7D (void);
// 0x00000044 System.Void HorizontalScrollerUI::UserPressedPlay()
extern void HorizontalScrollerUI_UserPressedPlay_mF1F82670A736EB5B838801782AE133D3D618D4B0 (void);
// 0x00000045 System.Void HorizontalScrollerUI::UserPressedPause()
extern void HorizontalScrollerUI_UserPressedPause_m89263923BBF973C0C6E8A0446FDBB23B0BF312B5 (void);
// 0x00000046 System.Void HorizontalScrollerUI::SetScoreText(System.String)
extern void HorizontalScrollerUI_SetScoreText_mF388A9EEC11877436F6E4A7653EDDDA7DBB8F0CD (void);
// 0x00000047 System.Void HorizontalScrollerUI::SetHighScoreText(System.String)
extern void HorizontalScrollerUI_SetHighScoreText_m1B39E75188DB710A425F43136B4790407C01C30F (void);
// 0x00000048 System.Void HorizontalScrollerUI::EnemyHitPlayer()
extern void HorizontalScrollerUI_EnemyHitPlayer_m65BB41DDF37E457A03D571A7F0D1AFAB20B7E420 (void);
// 0x00000049 System.Void HorizontalScrollerUI::UserDecidedToQuitTheGame()
extern void HorizontalScrollerUI_UserDecidedToQuitTheGame_mE6E0DFFD4E07839A9EFBB3348DA7A69D870F2092 (void);
// 0x0000004A System.Void HorizontalScrollerUI::Awake()
extern void HorizontalScrollerUI_Awake_mEBF5A901F9EA79719C8F0DB8326ECCD07CD0DBFF (void);
// 0x0000004B System.Void HorizontalScrollerUI::Start()
extern void HorizontalScrollerUI_Start_m4194C57F4C3E00CB5F2DAC0E7D95C2B58A045390 (void);
// 0x0000004C System.Void HorizontalScrollerUI::LateUpdate()
extern void HorizontalScrollerUI_LateUpdate_m30BCC8A83C74871795DB4B4DDA8A82F10A955D2D (void);
// 0x0000004D System.Void HorizontalScrollerUI::UserLost()
extern void HorizontalScrollerUI_UserLost_mD1A1C81D9B2EE7AC68EDA29EB07372752DB09BAB (void);
// 0x0000004E System.Void HorizontalScrollerUI::SaveCurrentHighScore()
extern void HorizontalScrollerUI_SaveCurrentHighScore_m7587138A898AC88D5BC53E7DDCE9F7E0DC9E8F1F (void);
// 0x0000004F System.Void HorizontalScrollerUI::ResetUI()
extern void HorizontalScrollerUI_ResetUI_mBB9E66BBD90C1EF7AFD088F5331C518AA62B0F20 (void);
// 0x00000050 System.Void HorizontalScrollerUI::.ctor()
extern void HorizontalScrollerUI__ctor_mED97451B7258400C95CC9F5363B581B3CC03CECC (void);
// 0x00000051 System.Void BackgroundControl_0::NextBG()
extern void BackgroundControl_0_NextBG_m90C28F80448D6F6589869096DB41ABF67547D137 (void);
// 0x00000052 System.Void BackgroundControl_0::BackBG()
extern void BackgroundControl_0_BackBG_m4B087FC70DB9D847535C001A890543B813CF6560 (void);
// 0x00000053 System.Void BackgroundControl_0::SetBG(System.Int32)
extern void BackgroundControl_0_SetBG_mE9A48E636B90B345080B82ABB29430B219865FBB (void);
// 0x00000054 System.Void BackgroundControl_0::Start()
extern void BackgroundControl_0_Start_mCBF731B1429D370D8CDB5AC643B4BEAF514471E6 (void);
// 0x00000055 System.Void BackgroundControl_0::Update()
extern void BackgroundControl_0_Update_m007E037FA97BFE0AC4FDB048FE7D8BAB40A78BEF (void);
// 0x00000056 System.Void BackgroundControl_0::ChangeSprite()
extern void BackgroundControl_0_ChangeSprite_m71061D630769D16B50A08E23C005B652C9651DB6 (void);
// 0x00000057 System.Void BackgroundControl_0::.ctor()
extern void BackgroundControl_0__ctor_m8945170629FF1B158310CDDC698DCC769FD971CE (void);
// 0x00000058 System.Void ParallaxBackground_0::Start()
extern void ParallaxBackground_0_Start_mEE281D4954E2E283D801FD2137A32F538AB269DA (void);
// 0x00000059 System.Void ParallaxBackground_0::Update()
extern void ParallaxBackground_0_Update_mDC7F9F0EEF96105D5C5E823A8DC32CAF8898E045 (void);
// 0x0000005A System.Void ParallaxBackground_0::.ctor()
extern void ParallaxBackground_0__ctor_m687F9D1FF13AF9442E31B1913A13DBCE229AB738 (void);
static Il2CppMethodPointer s_methodPointers[90] = 
{
	Bomb_Awake_m3CAE1647F328E5892A740D9B204F45CD6151FE7B,
	Bomb_OnEnable_m958CE4A6DEFF85ACDBFBEBDA11597CA4390ED6DE,
	Bomb_LateUpdate_mE0774F654B770E2DBCCA0AEC6D3A82B42D65D46E,
	Bomb_OnTriggerEnter2D_mA28DDFBF317D52558D3C862B97FE2CCACD536C4B,
	Bomb__ctor_mB4A4B674437E391EA003374752A044DD5E539C46,
	Car_get_CanUserControlCar_m8572284F5EFCD88356175AB5E4B28FB8F606E38F,
	Car_set_CanUserControlCar_mDB05A2D97C0C5BB52F25A3579BBB2188CED96644,
	Car_get_CurrentPlayerScore_m9837D40FBC143AD134B90BA2BA8F3018EB836C32,
	Car_set_CurrentPlayerScore_mBF251B44F6A5E2A60DE1ED861EEA36D0E1260E02,
	Car_get_SecondsSinceCarJumped_m7F28F63B0AA41937809824875028BF67486AF8BC,
	Car_set_SecondsSinceCarJumped_m4222904582351A40837ED7868D3BC5D826A7E3C9,
	Car_get_SecondsTraveled_m158517E5F70D02FE193C8E0ED2953A10A8EAEDB8,
	Car_set_SecondsTraveled_m3A39BDAD1EE34BA288BE48979B8E594C8F82DBA0,
	Car_SetCarLocation_m2293F8839C9B2E809672120115AAC25B73EED207,
	Car_SetCarLane_m2DAE9CE0E23AF7EDEA8E8AA542456E0B9D408A4A,
	Car_HitPooShiTokenObject_mB575C683F118DC320BFF09348CB885CBE55FA265,
	Car_HitEnemyObject_m12E4CAD61E63F2834BFF879B2C21560B29E19CF7,
	Car_PauseTires_m3EBB0006938DF58E224014B99942A2EFC2BD907A,
	Car_Awake_mC9635C2EA709050BC6D4D33E1BF86832E87EC810,
	Car_OnEnable_m56F5514A8EC5B8C8AC345DA8D41F179D57309096,
	Car_Update_mB15FECA4B76ADEA6E4C71AF5DDC72D8EC17E1D62,
	Car_OnDisable_mAECFB1D7A7DD266119B0A562CB2C81892BDC76C9,
	Car_CheckForCarLocationShift_m9352E1D652B746D4687CCE43104BFCB0A54FCB00,
	Car_checkSwipe_m9B007E8108EE06817B236F252590AEF7EEFDD2C4,
	Car_OnSwipeUp_mF32BA98869EA657A5E036C63F953C9BAFC62115D,
	Car_OnSwipeDown_mC4524A8D87D7641F3DF9C0A9BE43D91D556BB146,
	Car_OnSwipeLeft_mF67789B868BAF946577D852E3C3EF07911AFBD68,
	Car_OnSwipeRight_mAD96A20DD9C635BE120B6EB7165B8C7E126D319A,
	Car_verticalMove_m0B00BB61FC62C5BD7B1C429EF1AFD2D12979698B,
	Car_horizontalValMove_m59335620200DF2A2E67C15F0313EBA0AF856AF6F,
	Car_CheckForCarJumping_m44C5A9B8D13D706159190D0DB75F1B37AB31F3C2,
	Car_MakeCarJump_m76A85DA81CA8DB5E618E91D6F04DA41D89772444,
	Car__ctor_m60DBEB43627049079D3DB87585F1E132B1C4DC41,
	Boss_Awake_m32F745C33261137293AF3BBD526A529174C5AB58,
	Boss_OnEnable_m55182DBB17650F52FBF4AE94E78E1FAA201D8F29,
	Boss_Update_m7B73B59D0659578B1A73EB64D4586ADF8F594076,
	Boss_UpdateWinCondition_m21EF451957D90A1086FD4F0E9FA5BAF6CC03108C,
	Boss_OnDisable_m76EFE4AAC7E4DFA33360B2C6D21875C07F41F7E4,
	Boss_UpdateMovement_mDAD53B14F3AF7C65B362B05A3B4C1420FAE0529B,
	Boss_UpdateBossPositioning_mDD28F9F428DC253BD9809AB59920548F4DCD6D75,
	Boss_OnTriggerEnter2D_mD32AC8A2D12580C3817A0F21E2A3A8F9B70D4D9A,
	Boss_EagleDefeated_mBCD93039FC51A309FC65CD1304BE1B28906F02A6,
	Boss_EnsureBossFacesCar_m2F76F04AA408DFD059A5A6DC30D63033BEC4842F,
	Boss__ctor_mCEB1D7BFC2C85DF7CE281A5BB76D0D55ADFB089F,
	U3CEagleDefeatedU3Ed__40__ctor_mC9FAA57839803C59541F79B634A4C2D14C21E668,
	U3CEagleDefeatedU3Ed__40_System_IDisposable_Dispose_m93894B4013E24145808485BD9BE48ECBC6351454,
	U3CEagleDefeatedU3Ed__40_MoveNext_m6B3CF1042B162B6CA98459163E21BDD267E013E3,
	U3CEagleDefeatedU3Ed__40_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m12397C7DFA237A3F2B3F437A2476D62B5E50E500,
	U3CEagleDefeatedU3Ed__40_System_Collections_IEnumerator_Reset_m5FE885E4B9EC1EC55287B05E3F8FAFF5AD0761C6,
	U3CEagleDefeatedU3Ed__40_System_Collections_IEnumerator_get_Current_m182C7C1F23627D8E12D971B13A12450726A8DEC1,
	PooShi_Awake_mFE54EC4322737B548473ACB9074B0B5AEB820EC3,
	PooShi_OnTriggerEnter2D_mF33DF71F37CF957528CC48F69D5B50B9A9B215D6,
	PooShi__ctor_mEFECE90667F14E7B25A792FAD2C75DE34F569395,
	PooShiToken_LateUpdate_mCB9763D3D4E607D9F3966ED9C29F728FFA746CB7,
	PooShiToken_Awake_mCEB19DA91375FA624556B71318B44093A8516AE9,
	PooShiToken_OnTriggerEnter2D_mFDBA78D9845C1BED18D7645E39EC216FDA863DE0,
	PooShiToken__ctor_mCED088E476E47F0A397EE63BCC3D32EEFE67CF6F,
	EnemyManager_ActivateTheBoss_m3F8FC1675888FDF693A536945DBE768068773E30,
	EnemyManager_DeactivateTheBoss_m2A7127F09B0CBA522D92BAFB5531C5315DA46419,
	EnemyManager_ActivateBombTokenSpawner_m14FB41BCD0BD053517BBFA431A403C09A86BCF48,
	EnemyManager_DeactivateBombTokenSpawner_m0F5EE07A94C3F7CE4F4DBE4A1A2A592EAB5A9E35,
	EnemyManager_ActivateNextEnemy_m195BE71D15445330107EEC61639570B0EDCC697A,
	EnemyManager_Awake_mCF0CE37D0C822B260FC50D3E278273C48E1EAFFD,
	EnemyManager_Update_mDAF54A6B65BC212734D1F2A4A6113774B609D144,
	EnemyManager_OnDisable_m137513726C7A2C599CFFF2E62DE5EDA04A0A0A53,
	EnemyManager__ctor_mBDFE0474595BA9BB75EA8A31AD431DD91E7EB250,
	HorizontalScrollerUI_UserWon_mC6D3206A2C964D0B09F5AD083F3F013DD2DECE7D,
	HorizontalScrollerUI_UserPressedPlay_mF1F82670A736EB5B838801782AE133D3D618D4B0,
	HorizontalScrollerUI_UserPressedPause_m89263923BBF973C0C6E8A0446FDBB23B0BF312B5,
	HorizontalScrollerUI_SetScoreText_mF388A9EEC11877436F6E4A7653EDDDA7DBB8F0CD,
	HorizontalScrollerUI_SetHighScoreText_m1B39E75188DB710A425F43136B4790407C01C30F,
	HorizontalScrollerUI_EnemyHitPlayer_m65BB41DDF37E457A03D571A7F0D1AFAB20B7E420,
	HorizontalScrollerUI_UserDecidedToQuitTheGame_mE6E0DFFD4E07839A9EFBB3348DA7A69D870F2092,
	HorizontalScrollerUI_Awake_mEBF5A901F9EA79719C8F0DB8326ECCD07CD0DBFF,
	HorizontalScrollerUI_Start_m4194C57F4C3E00CB5F2DAC0E7D95C2B58A045390,
	HorizontalScrollerUI_LateUpdate_m30BCC8A83C74871795DB4B4DDA8A82F10A955D2D,
	HorizontalScrollerUI_UserLost_mD1A1C81D9B2EE7AC68EDA29EB07372752DB09BAB,
	HorizontalScrollerUI_SaveCurrentHighScore_m7587138A898AC88D5BC53E7DDCE9F7E0DC9E8F1F,
	HorizontalScrollerUI_ResetUI_mBB9E66BBD90C1EF7AFD088F5331C518AA62B0F20,
	HorizontalScrollerUI__ctor_mED97451B7258400C95CC9F5363B581B3CC03CECC,
	BackgroundControl_0_NextBG_m90C28F80448D6F6589869096DB41ABF67547D137,
	BackgroundControl_0_BackBG_m4B087FC70DB9D847535C001A890543B813CF6560,
	BackgroundControl_0_SetBG_mE9A48E636B90B345080B82ABB29430B219865FBB,
	BackgroundControl_0_Start_mCBF731B1429D370D8CDB5AC643B4BEAF514471E6,
	BackgroundControl_0_Update_m007E037FA97BFE0AC4FDB048FE7D8BAB40A78BEF,
	BackgroundControl_0_ChangeSprite_m71061D630769D16B50A08E23C005B652C9651DB6,
	BackgroundControl_0__ctor_m8945170629FF1B158310CDDC698DCC769FD971CE,
	ParallaxBackground_0_Start_mEE281D4954E2E283D801FD2137A32F538AB269DA,
	ParallaxBackground_0_Update_mDC7F9F0EEF96105D5C5E823A8DC32CAF8898E045,
	ParallaxBackground_0__ctor_m687F9D1FF13AF9442E31B1913A13DBCE229AB738,
};
static const int32_t s_InvokerIndices[90] = 
{
	1810,
	1810,
	1810,
	1513,
	1810,
	1786,
	1531,
	1789,
	1534,
	1789,
	1534,
	1789,
	1534,
	1554,
	1534,
	1810,
	1810,
	1810,
	1810,
	1810,
	1810,
	1810,
	1810,
	1810,
	1810,
	1810,
	1810,
	1810,
	1789,
	1789,
	1810,
	1810,
	1810,
	1810,
	1810,
	1810,
	1810,
	1810,
	1810,
	1810,
	1513,
	1766,
	1810,
	1810,
	1501,
	1810,
	1786,
	1766,
	1810,
	1766,
	1810,
	1513,
	1810,
	1810,
	1810,
	1513,
	1810,
	1810,
	1810,
	1810,
	1810,
	867,
	1810,
	1810,
	1810,
	1810,
	1810,
	1810,
	1810,
	1513,
	1513,
	1810,
	1810,
	1810,
	1810,
	1810,
	1810,
	1810,
	1810,
	1810,
	1810,
	1810,
	1501,
	1810,
	1810,
	1810,
	1810,
	1810,
	1810,
	1810,
};
extern const CustomAttributesCacheGenerator g_AssemblyU2DCSharp_AttributeGenerators[];
IL2CPP_EXTERN_C const Il2CppCodeGenModule g_AssemblyU2DCSharp_CodeGenModule;
const Il2CppCodeGenModule g_AssemblyU2DCSharp_CodeGenModule = 
{
	"Assembly-CSharp.dll",
	90,
	s_methodPointers,
	0,
	NULL,
	s_InvokerIndices,
	0,
	NULL,
	0,
	NULL,
	0,
	NULL,
	NULL,
	g_AssemblyU2DCSharp_AttributeGenerators,
	NULL, // module initializer,
	NULL,
	NULL,
	NULL,
};
